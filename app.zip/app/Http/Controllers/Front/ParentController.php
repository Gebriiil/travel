<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;

class ParentController extends Controller
{


    public $shared_data = array();


    public function __construct()
    {

    }


}
