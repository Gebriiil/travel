@include('front2.includes.header')
@include('front2.includes.nav')
@yield('content')
</div>
@include('front2.includes.footer')