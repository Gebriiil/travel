<div class="row">
  <div class="col-sm-12">
    <ul id="errors"></ul>
  </div>
</div>