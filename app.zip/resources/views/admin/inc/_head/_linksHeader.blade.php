
@if(app()->getLocale() == 'ar')


 <!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<link href="{{aurl_ar()}}/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl_ar()}}/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl_ar()}}/global/plugins/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl_ar()}}/global/plugins/bootstrap-switch/css/bootstrap-switch-rtl.min.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN THEME GLOBAL STYLES -->
<link href="{{aurl_ar()}}/global/css/components-rtl.min.css" rel="stylesheet" id="style_components" type="text/css" />
<link href="{{aurl_ar()}}/global/css/plugins-rtl.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME GLOBAL STYLES -->
<!-- BEGIN THEME LAYOUT STYLES -->
<link href="{{aurl_ar()}}/layouts/layout/css/layout-rtl.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl_ar()}}/layouts/layout/css/themes/darkblue-rtl.min.css" rel="stylesheet" type="text/css" id="style_color" />
<link href="{{aurl_ar()}}/layouts/layout/css/custom-rtl.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME LAYOUT STYLES -->
<link rel="shortcut icon" href="favicon.ico" /> 

<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">
<link href="{{aurl()}}/seoera/css/endStyleAr.css" rel="stylesheet" type="text/css" />

 <link href="{{aurl()}}/global/plugins/select2/css/select2.min.css" rel="stylesheet"
       type="text/css"/>
 <link href="{{aurl()}}/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet"
       type="text/css"/>



@else



 <!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
<link href="{{aurl()}}/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl()}}/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl()}}/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl()}}/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN THEME GLOBAL STYLES -->
<link href="{{aurl()}}/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
<link href="{{aurl()}}/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME GLOBAL STYLES -->
<!-- BEGIN THEME LAYOUT STYLES -->
<link href="{{aurl()}}/layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
<link href="{{aurl()}}/layouts/layout/css/themes/darkblue.min.css" rel="stylesheet" type="text/css" id="style_color" />
<link href="{{aurl()}}/layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
<!-- END THEME LAYOUT STYLES -->
<link rel="shortcut icon" href="favicon.ico" /> 
<link href="{{aurl()}}/seoera/css/endStyle.css" rel="stylesheet" type="text/css" />

 <link href="{{aurl()}}/global/plugins/select2/css/select2.min.css" rel="stylesheet"
       type="text/css"/>
 <link href="{{aurl()}}/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet"
       type="text/css"/>



@endif


