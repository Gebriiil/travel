$(function (){
	$('#newsletter-submit').on('click',function(){
			var email =$('#newsletter').val();
			
		});
});