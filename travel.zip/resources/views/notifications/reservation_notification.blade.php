<html>
<head>


</head>
<body>
<h1 style="text-align: center;font-style: italic">Panorama Egypt Tours</h1>

<table style="width: 100%; text-align: center; border: 1px solid #ddd;">
    <thead style="background: #ddd; font-family: tahoma; font-size: 14px;">
    <tr style="height: 50px;">

    </tr>
    </thead>
    <tbody>

    <tr style="height: 50px">

        <th style="width: 150px;"> Tour</th>
        <td>
            {{$tour}}
        </td>


    </tr>
    <tr style="height: 50px">

        <th style="width: 150px;"> Name</th>
        <td>
            {{$name}}
        </td>


    </tr>
    <tr style="height: 50px">

        <th style="width: 150px;"> Phone</th>
        <td>
            {{$phone}}
        </td>


    </tr>
    <tr style="height: 50px">

        <th style="width: 150px;"> Email</th>
        <td>
            {{$email}}
        </td>


    </tr>
    <tr style="height: 50px">

        <th style="width: 150px;"> Arrival Date</th>
        <td>
            {{$arrival_date}}
        </td>


    </tr>

    <tr style="height: 50px">

        <th style="width: 150px;"> Departure Date</th>
        <td>
            {{$departure_date}}
        </td>


    </tr>
    <tr style="height: 50px">

        <th style="width: 150px;"> Adults</th>
        <td>
            {{$adults}}
        </td>


    </tr>

    <tr style="height: 50px">

        <th style="width: 150px;"> Childrens</th>
        <td>
            {{$childrens}}
        </td>


    </tr>


    <tr style="height: 50px">

        <th style="width: 150px;"> Message</th>
        <td>
            {{$msg}}
        </td>


    </tr>


    </tbody>
</table>


<h1 style="text-align: center;font-style: italic">Thanks</h1>
</body>
</html>
