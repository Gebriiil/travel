@component('mail::message')
# Introduction

{{$msg}}



Thanks,<br>
Panorama
@endcomponent
