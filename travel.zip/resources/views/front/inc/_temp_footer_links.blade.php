

<!-- <script src="{{ asset(mix('js/laravel-mix-all.js')) }}" ></script> -->
<!-- REVOLUTION JS FILES -->
<!-- 
<script src="{{furl()}}/js/libs/revolution/jquery.themepunch.tools.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/jquery.themepunch.revolution.min.js"></script> -->



<!-- Scripts -->





<!-- Scripts -->
<script src="{{furl()}}/js/libs/jquery-1.12.4.min.js"></script><!-- jQuery -->
<script src="{{furl()}}/js/libs/stellar.min.js"></script><!-- parallax -->
<script src="{{furl()}}/js/libs/bootstrap.min.js"></script><!-- Bootstrap -->
<script src="{{furl()}}/js/libs/smoothscroll.min.js"></script><!-- smoothscroll -->
<script src="{{furl()}}/js/libs/owl.carousel.min.js"></script><!-- Owl Carousel -->
<script src="{{furl()}}/js/libs/jquery.magnific-popup.min.js"></script><!-- Magnific Popup -->
<script src="{{furl()}}/js/libs/theia-sticky-sidebar.min.js"></script><!-- Sticky sidebar -->
<script src="{{furl()}}/js/libs/counter-box.min.js"></script><!-- counter -->
<script src="{{furl()}}/js/libs/jquery.flexslider-min.js"></script><!-- flexslider -->
<script src="{{furl()}}/js/libs/jquery.thim-content-slider.min.js"></script><!-- Slider -->
<script src="{{furl()}}/js/libs/gallery.min.js"></script><!-- gallery -->
<script src="{{furl()}}/js/libs/moment.min.js"></script><!-- moment -->
<script src="{{furl()}}/js/libs/jquery-ui.min.js"></script><!-- ui -->
<script src="{{furl()}}/js/libs/daterangepicker.min.js"></script><!-- date -->
<script src="{{furl()}}/js/libs/daterangepicker.min-date.min.js"></script><!-- date2 -->
<script src="{{furl()}}/js/theme-customs.js"></script><!-- Theme Custom -->

<!-- REVOLUTION JS FILES -->
<script  src="{{furl()}}/js/libs/revolution/jquery.themepunch.tools.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.actions.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.carousel.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.kenburn.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.migration.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.navigation.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.parallax.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.slideanims.min.js"></script>
<script src="{{furl()}}/js/libs/revolution/extensions/revolution.extension.video.min.js"></script>



@yield('ajax')