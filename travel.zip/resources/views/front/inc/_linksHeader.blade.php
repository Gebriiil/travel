   <!-- Favicons -->
   <link rel="shortcut icon" href="{{furl()}}/images/icons/favicon.png">

   <!-- REVOLUTION STYLE SHEETS -->
   <link rel="stylesheet" href="{{furl()}}/css/style.css">