<?php

use Faker\Generator as Faker;

$factory->define(App\DailyPricingHotel::class, function (Faker $faker) {
    return [
        //
    ];
});
