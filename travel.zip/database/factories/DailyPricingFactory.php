<?php

use Faker\Generator as Faker;

$factory->define(App\DailyPricing::class, function (Faker $faker) {
    return [
        //
    ];
});
