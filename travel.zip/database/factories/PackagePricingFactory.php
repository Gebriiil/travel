<?php

use Faker\Generator as Faker;

$factory->define(App\PackagePricing::class, function (Faker $faker) {
    return [
        //
    ];
});
