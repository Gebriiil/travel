<?php

namespace App\Http\Controllers;

use App\PackagePricingHotel;
use Illuminate\Http\Request;

class PackagePricingHotelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PackagePricingHotel  $packagePricingHotel
     * @return \Illuminate\Http\Response
     */
    public function show(PackagePricingHotel $packagePricingHotel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PackagePricingHotel  $packagePricingHotel
     * @return \Illuminate\Http\Response
     */
    public function edit(PackagePricingHotel $packagePricingHotel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PackagePricingHotel  $packagePricingHotel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PackagePricingHotel $packagePricingHotel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PackagePricingHotel  $packagePricingHotel
     * @return \Illuminate\Http\Response
     */
    public function destroy(PackagePricingHotel $packagePricingHotel)
    {
        //
    }
}
